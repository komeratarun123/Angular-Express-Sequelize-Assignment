import { Injectable } from '@angular/core';
import { HttpClient, JsonpClientBackend } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class PolicyService {

  constructor(private http:HttpClient) { }
  PolicyUrl="http://localhost:8001";
  getAllPolicyData():Observable<any>
  {
      var URL= this.PolicyUrl+"/getAllInsurance";
      return this.http.get(URL);
  }
  getAllPolicyDataById(id:any):Observable<any>
  {
   
        var URL=this.PolicyUrl+"/getInsuranceById/"+id;
        console.log(URL);
        return this.http.get(URL);
  }
  insertPolicy(PolicyObj:any):Observable<any>
  {
        var URL=this.PolicyUrl+"/newRecord";
        let header ={'content-type':'application/json'};

        return this.http.post(URL,PolicyObj,{'headers':header,responseType:'text'});
  }
  updatePolicyData(PolicyObj:any):Observable<any>
  {
    var URL=this.PolicyUrl+"/updatePolicy";

    let header ={'content-type':'application/json'}
    return this.http.put(URL,PolicyObj,{'headers':header,'responseType':'text'});
  }
  deletePolicy(id:any):Observable<any>
  {
    var URL=this.PolicyUrl+"/deletePolicy/"+id;
    return this.http.delete(URL,{responseType:'text'});

  }
}
