import { Injectable } from '@angular/core';
import { HttpClient, JsonpClientBackend } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http:HttpClient) { }
  
    LoginUrl="http://localhost:8000";
  
  validUser(loginform:any):Observable<any>{
       var URL=this.LoginUrl+'/login';
       var body=JSON.stringify(loginform);
       
       let header ={'content-type':'application/json'};
        return this.http.post(URL,body,{'headers':header,responseType:'json'});
  }
}
