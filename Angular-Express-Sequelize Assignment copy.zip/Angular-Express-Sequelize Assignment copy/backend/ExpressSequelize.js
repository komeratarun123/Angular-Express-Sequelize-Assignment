const express =require("express");
const Sequelize=require("sequelize");
const app=express();
const db2= require("./db.config");
var cors=require('cors');
app.use(cors());
var sequelize= new Sequelize(db2.DB,db2.USER,db2.PASSWORD,{
   host:db2.HOST,
   dialect:db2.dialect,
   pool:{
       max:db2.pool.max,
       min:db2.pool.min,
       acquire:db2.pool.acquire,
       idle:db2.pool.idle
   }
});

let InsuranceTable= sequelize.define('InsuranceTable',{
    PolicyNumber :{
        primaryKey:true,
        type:Sequelize.INTEGER
    },
    PolicyHoldersName:Sequelize.STRING,
    PolicyAmt:Sequelize.INTEGER,
    MaturityAmount: Sequelize.INTEGER,
    Nominee:Sequelize.STRING
},{
    timestamps:false,
    freezeTableName:true
});

// InsuranceTable.sync({force:true}).then(()=>{
//     console.log("Table Created successfully");
// }).catch(err=>{
//      console.log("Error in Creation"+err);
// })
// let UserTable= sequelize.define('UserTable',{
//     UserName :{
//         primaryKey:true,
//         type:Sequelize.STRING
//     },
//     Password:Sequelize.STRING,
//     Role:Sequelize.STRING
   
// },{
//     timestamps:false,
//     freezeTableName:true
// });
// UserTable.sync({force:true}).then(()=>{
//     console.log("Table Created successfully");
// }).catch(err=>{
//      console.log("Error in Creation"+err);
// })

app.get('/getAllInsurance',(req,res)=>{

    InsuranceTable.findAll({raw:true}).then((data)=>{
        console.log("All Record in database");
        console.log(data);
        res.send(data);
    }).catch(err=>{
        console.log("Error in Creation");
        res.status(400),send(err);
    })
})
app.get('/getInsuranceById/:Id',(req,res)=>{
    var id=req.params.Id;
    InsuranceTable.findByPk(id,{raw:true}).then(data=>{
                console.log(data);
                res.status(200).send(data)
    }).catch(err=>{
        console.log(err);
        res.status(400).send(err);
    })
})
app.use(express.json())
app.post('/newRecord',(req,res)=>{
    var PolicyNumber =  req.body.PolicyNumber;
    var PolicyHoldersName =  req.body.PolicyHoldersName;
    var PolicyAmt =  req.body.PolicyAmt;
    var MaturityAmount =  req.body.MaturityAmount;
    var Nominee =  req.body.Nominee;
    var InsuranceObj=InsuranceTable.build({PolicyNumber:PolicyNumber,PolicyHoldersName:PolicyHoldersName,
        PolicyAmt:PolicyAmt,MaturityAmount:MaturityAmount,Nominee:Nominee});
    InsuranceObj.save().then(()=>{
        console.log("Successfully inserted");
        res.status(201).send("Inserted Successfully");
    }).catch((err)=>{
        console.log("Error Encountered"+err);
        res.status(400).send("Error Encountered");
    })
})

app.put('/updatePolicy',(req,res)=>{
    var PolicyNumber =  req.body.PolicyNumber;
    var PolicyHoldersName =  req.body.PolicyHoldersName;
    var PolicyAmt =  req.body.PolicyAmt;
    var MaturityAmount =  req.body.MaturityAmount;
        InsuranceTable.update(
           {PolicyHoldersName:PolicyHoldersName,PolicyAmt:PolicyAmt,MaturityAmount:MaturityAmount},
           {where:{PolicyNumber:PolicyNumber}}
       ).then(data=>{
           console.log(data);
           var str ="Record updated successfully";
           console.log(str);
           res.status(201).send(str);
       }).catch(err =>{
           console.log("there is a error in updating the table");
           res.status(400).send(err);
       })
})
app.delete('/deletePolicy/:Id',(req,res)=>{
    var Id =req.params.Id;
    InsuranceTable.destroy({where:{PolicyNumber:Id}}).then(()=>{
        console.log("Deleted Successfully");
        res.status(200).send("Deleted Successfully");
    }).catch((err)=>{
        console.log("Error Encountered");
        res.status(400).send(err);
    })
})

app.post('/login',(req,res)=>{
     var UserName=req.body.UserName;
     var  Password=req.body.Password;
     var Role =req.body.Role;
     const Op=Sequelize.Op;
     UserTable.findAll({raw:true}).then((data)=>{
        var flag=0;
         for(var i=0;i<data.length;i++){
             if(data[i].UserName==UserName && data[i].Password==Password && data[i].Role==Role)
               {
                   flag=1;
                   break;
               }
         }
         if(flag==1){
             console.log("User Login Successful");
             res.status(201).send("User Login Successful");
         }else{
            console.log("User Login UnSuccessful");
            res.status(401).send("User Login UnSuccessful");  
         }
        }).catch((err)=>{
            console.log("Error Encountered");
            res.status(400).send("Error Occured");
        })
     })
app.post('/register',(req,res)=>{
    var UserName=req.body.UserName;
    var  Password=req.body.Password;
    var Role =req.body.Role;
     var UserObj=UserTable.build({UserName:UserName,Password:Password,Role:Role})
     UserObj.save().then(()=>{
         console.log("User Register Successfully");
         res.status(201).send("User Registered Successfully");
     }).catch((err)=>{
         console.log(err);
         res.status(400).send("User Not Registered Successfully");
     })
})
app.listen(8001,function(){
    console.log("Server is listening");
})


